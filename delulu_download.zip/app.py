from flask import Flask, request, render_template, send_file
from pytube import YouTube
import os

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        url = request.form["url"]
        file_format = request.form["format"]
        yt = YouTube(url)

        if file_format == "video":
            stream = yt.streams.filter(progressive=True, file_extension="mp4").order_by("resolution").desc().first()
        else:
            stream = yt.streams.filter(only_audio=True).first()

        out_file = stream.download(filename="temp.mp4")
        if file_format == "audio":
            base, _ = os.path.splitext(out_file)
            new_file = base + ".mp3"
            os.rename(out_file, new_file)
            return send_file(new_file, as_attachment=True)
        return send_file(out_file, as_attachment=True)

    return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True)
